package _kakao;

public class Global {
    public static final String HOST_URL = "https://pegkq2svv6.execute-api.ap-northeast-2.amazonaws.com/prod/users";
    public static final String POST_START = "/start";
    public static final String GET_LOCATIONS = "/locations";
    public static final String GET_TRUCKS = "/trucks";
    public static final String PUT_SIMULATE = "/simulate";
    public static final String GET_SCORE = "/score";
    public static final String X_AUTH_TOKEN = "65275e43545016e931d6d9de5861ca4e";
}
