import sys
import logging
import pymysql

def lambda_handler(event, context):
    conn = pymysql.connect(host="sdp-visualization-map.cans4pgyqcr1.ap-northeast-2.rds.amazonaws.com/visualization",
                           user="admin", password="sdp_maps!", db="map")
    curs = conn.cursor()
    sql = "select * from map"
    curs.execute(sql)
    rows = curs.fetchall()
    result = 0
    for row in rows:
        result = row[1]
    conn.close()
    return result

